package GUIFiles;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import javax.swing.table.*;
import UserManagement.*;


public class Dashboard  extends JFrame implements ActionListener{

    Font font15 = new Font("Consolas",Font.PLAIN, 15);
    Font font18 = new Font("Consolas",Font.PLAIN, 18);
    Font timesRoman25 = new Font("TimesRoman",Font.BOLD, 25);
    Font timesRoman18 = new Font("TimesRoman",Font.PLAIN, 18);
    Font timesRoman30 = new Font("TimesRoman",Font.BOLD, 30);
    Font timesRoman25p = new Font("TimesRoman",Font.PLAIN, 25);

    JTextField name, id, address;
    JButton add, logout, signup;
    JLabel output,text,label, label2;

    //DefaultTableModel tableModel = new DefaultTableModel();

    Dashboard(){

        
        super("Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLocation(150, 100);
        setLayout(null);

        label = new JLabel("User Dashboard");
        label.setBounds(520,0,300,50);
        label.setFont(timesRoman30);
        add(label);

        label2 = new JLabel("WELCOME TO OUR ONLINE PORTAL");
        label2.setBounds(370,40,750,50);
        label2.setFont(timesRoman25p);
        add(label2);


        

//---------------------------------------------------------------------       

       /* JLabel lName = new JLabel("Name  ");
        lName.setBounds(50, 50, 60, 30); 
        lName.setFont(font15);
        add(lName);

        name = new JTextField();
        name.setBounds(130, 50, 200, 30 );
        name.setFont(font15);
        add(name);
//---------------------------------------------------------------------
        JLabel lid = new JLabel("ID   ");
        lid.setBounds(50, 105, 60, 15); //x,y,w,h
        lid.setFont(font15);
        add(lid);

        id = new JTextField();
        id.setBounds(130, 100, 200, 30 );
        id.setFont(font15);
        add(id); 

//---------------------------------------------------------------------
        JLabel laddress = new JLabel("Address ");
        laddress.setBounds(50, 150, 100, 30); //x,y,w,h
        laddress.setFont(font15);
        add(laddress);

        address = new JTextField();
        address.setBounds(130, 150, 200, 30 );
        address.setFont(font15);
        add(address); 
//---------------------------------------------------------------------   
        add = new JButton("Add Data");
        add.setBounds(100, 200, 150, 30);
        add.setFont(font15);
        add.setFocusable(false);
        add.addActionListener(this);
        add(add);

//---------------------------------------------------------------------   

//--------------------------------------------------------------------- 

        output = new JLabel();
        output.setBounds(250, 250, 150, 30); //x,y,w,h
        output.setFont(font15);
        add(output);

        tableModel.addColumn("Name");
        tableModel.addColumn("ID");
        tableModel.addColumn("Address");
         
        JTable table = new JTable(tableModel);
        JScrollPane jScrollPane = new JScrollPane(table);
        jScrollPane.setBounds(600, 50, 500,500);
        add(jScrollPane);

        */ 
        
   //---------------------------------------------------------------------  
   
   
        logout = new JButton("Logout");
        logout.setBounds(40, 500, 150, 30); //x,y,w,h
        logout.setFont(font15);
        logout.addActionListener(this);
        logout.setFocusable(false);
        add(logout);
      
        //---------------------------------------------------------------------   

       /*  text = new JLabel("Already have an account");
        text.setBounds(350,500,195,30);
        text.setFont(font15);
        add(text);
        */





        setVisible(true);

        loadData();

    }  //--------------------------------------------------------------------- 

    public void actionPerformed(ActionEvent event){

        if(event.getSource() == add){

           // tableModel.addRow(new Object[]{name.getText(),id.getText(),address.getText()});
        

        }else if (event.getSource() == logout) {

            int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
            
                dispose(); 
                Login login = new Login(); 
            }
            
        }



    }
//--------------------------------------------------------------------- 

//--------------------------------------------------------------------- 
    
public void loadData() {
    UserManagement userManagement = new UserManagement();
    User[] students = userManagement.getAll();

    if (students != null && students.length > 0) {
        
        

        
        for (User user : students) {
            String userName = user.getuserName();  
            String password = user.getPassword();  
            String name = user.getName();   
            label2.setText("Hey "+ name + ", " +"Welcome to our online portal" );  
            //text.setText(name);    
            
        }
    } else {
        JOptionPane.showMessageDialog(null, "No users found");
    }
}

//--------------------------------------------------------------------- 
     
    



    
}