package GUIFiles;
import UserManagement.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class SignUp extends JFrame implements ActionListener {

    Font font15 = new Font("Consolas",Font.PLAIN, 15);
    Font font18 = new Font("Consolas",Font.PLAIN, 18);
    Font timesRoman = new Font("TimesRoman",Font.BOLD, 25);
    Font timesRoman18 = new Font("TimesRoman",Font.PLAIN, 18);


    JLabel label,text, userNameText , nameText, mobileText, passwordText , genderText;
    JTextField userName, name, mobile;
    JPasswordField password;
    JButton buttonLoginText, register;
    JRadioButton rbtnMale,rbtnFemale;


    SignUp(){

        super("Sign-Up");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLocation(150, 100);
        setLayout(null);

        label = new JLabel("SIGN-UP");
        label.setBounds(550,30,200,50);
        label.setFont(timesRoman);
        add(label);
//-----------------------------------------------------------------------------------

        userNameText = new JLabel("Username ");
        userNameText.setBounds(400,100,100,40);
        userNameText.setFont(timesRoman18);
        add(userNameText);

        userName = new JTextField();
        userName.setBounds(495, 100, 250, 40 );
        userName.setFont(timesRoman18);
        add(userName);

//-----------------------------------------------------------------------------------  

        nameText = new JLabel("Name ");
        nameText.setBounds(400,150,100,40);
        nameText.setFont(timesRoman18);
        add(nameText);

        name = new JTextField();
        name.setBounds(495, 150, 250, 40 );
        name.setFont(timesRoman18);
        add(name);


//-----------------------------------------------------------------------------------

                
        mobileText = new JLabel("Mobile ");
        mobileText.setBounds(400,200,100,40);
        mobileText.setFont(timesRoman18);
        add(mobileText);

        mobile = new JTextField();
        mobile.setBounds(495, 200, 250, 40 );
        mobile.setFont(timesRoman18);
        add(mobile);


//-----------------------------------------------------------------------------------


              
        passwordText = new JLabel("Password ");
        passwordText.setBounds(400,250,100,40);
        passwordText.setFont(timesRoman18);
        add(passwordText);

        password = new JPasswordField();
        password.setBounds(495, 250, 250, 40 );
        password.setFont(timesRoman18);
        add(password);
//-----------------------------------------------------------------------------------

        genderText = new JLabel("Gender ");
        genderText.setBounds(400,300,100,40);
        genderText.setFont(timesRoman18);
        add(genderText);

        ButtonGroup group = new ButtonGroup();
        

        rbtnMale = new JRadioButton("Male");
        rbtnMale.setBounds(500, 290, 100, 60); //x,y,w,h
        rbtnMale.setFont(timesRoman18);
        rbtnMale.setFocusable(false);
        rbtnMale.addActionListener(this);
        group.add(rbtnMale);
        add(rbtnMale);

        rbtnFemale = new JRadioButton("Female");
        rbtnFemale.setBounds(650, 290, 100, 60); //x,y,w,h
        rbtnFemale.setFont(timesRoman18);
        rbtnFemale.addActionListener(this);
        rbtnFemale.setFocusable(false);
        group.add(rbtnFemale);
        add(rbtnFemale);

        


       

//-----------------------------------------------------------------------------------

        register = new JButton("Register");
        register.setBounds(490, 375, 250, 40); //x,y,w,h
        register.setFont(timesRoman18);
        register.addActionListener(this);
        register.setFocusable(false);
        add(register);


//-----------------------------------------------------------------------------------

        text = new JLabel("Already have an account");
        text.setBounds(350,500,195,30);
        text.setFont(font15);
        add(text);

        buttonLoginText = new JButton("Login");
        buttonLoginText.setBounds(550, 500, 150, 30); //x,y,w,h
        buttonLoginText.setFont(font15);
        buttonLoginText.addActionListener(this);
        buttonLoginText.setFocusable(false);
        add(buttonLoginText);

//-----------------------------------------------------------------------------------


       register.addActionListener(new ActionListener() {
        public void actionPerformed(ActionEvent event){

                String usernameT = userName.getText();
                String nameT = name.getText();
                String mobileT = mobile.getText();
                String passwordT = password.getText();


                String gender;

                if (rbtnMale.isSelected()) {
                        gender = "Male";
                        
                }else {
                        gender = "Female";    
                }
                
               

                
                if (userName.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Username fill cannot empty");
                        userName.requestFocus();
                        
                }else if (name.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Name fill cannot empty");
                }
                else if (mobile.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Mobile fill cannot empty");
                }
                else if (password.getText().isEmpty()) {
                        JOptionPane.showMessageDialog(null, "Password fill cannot empty");
                }else {

                        UserManagement userManagement = new UserManagement();
                        User user = new User(usernameT, nameT, mobileT, passwordT, gender);
                        userManagement.creatUser(user);
                        
                        Dashboard dashboard = new Dashboard();
                        
                }   
                
                
        }
        
        
       });



        

        setVisible(true);


    }

    public void actionPerformed(ActionEvent event){

        if(event.getSource() == buttonLoginText){
            Login login = new Login();

        }else if (event.getSource()==register) {

                
        }
}


    

   

    
}