
package GUIFiles;
import UserManagement.*;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;


public class Login extends JFrame implements ActionListener {

    Font font15 = new Font("Consolas",Font.PLAIN, 15);
    Font font18 = new Font("Consolas",Font.PLAIN, 18);
    Font timesRoman25 = new Font("TimesRoman",Font.BOLD, 25);
    Font timesRoman18 = new Font("TimesRoman",Font.PLAIN, 18);
    Font timesRoman30 = new Font("TimesRoman",Font.BOLD, 30);

    JTextField userName;
    JPasswordField password;
    JButton buttonSignUpText, loginBtn;
    JLabel text, label,label2,userNameText,passwordText;



    public Login(){


        super("Login");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLocation(150, 100);
        setLayout(null);

        label = new JLabel("WELCOME TO OUR ONLINE PORTAL");
        label.setBounds(320,30,550,50);
        label.setFont(timesRoman30);
        add(label);

        label2 = new JLabel("LOGIN");
        label2.setBounds(550,90,200,50);
        label2.setFont(timesRoman25);
        add(label2);

//---------------------------------------------------------------------       

        
        userNameText = new JLabel("Username ");
        userNameText.setBounds(400,170,100,40);
        userNameText.setFont(timesRoman18);
        add(userNameText);

        userName = new JTextField();
        userName.setBounds(495, 170, 250, 40 );
        userName.setFont(timesRoman18);
        add(userName);
       
//---------------------------------------------------------------------
                  
        passwordText = new JLabel("Password ");
        passwordText.setBounds(400,220,100,40);
        passwordText.setFont(timesRoman18);
        add(passwordText);

        password = new JPasswordField();
        password.setBounds(495, 220, 250, 40 );
        password.setFont(timesRoman18);
        add(password);

//---------------------------------------------------------------------
        
        loginBtn = new JButton("Login");
        loginBtn.setBounds(495, 280, 250, 40); //x,y,w,h
        loginBtn.setFont(timesRoman18);
        loginBtn.addActionListener(this);
        loginBtn.setFocusable(false);
        add(loginBtn);


//---------------------------------------------------------------------   
       
//---------------------------------------------------------------------   

       
//--------------------------------------------------------------------- 

      
//---------------------------------------------------------------------   

        text = new JLabel("I have an no account");
        text.setBounds(350,500,195,30);
        text.setFont(font15);
        add(text);

        buttonSignUpText = new JButton("Sign-Up");
        buttonSignUpText.setBounds(550, 500, 150, 30); //x,y,w,h
        buttonSignUpText.setFont(font15);
        buttonSignUpText.addActionListener(this);
        buttonSignUpText.setFocusable(false);
        add(buttonSignUpText);


//---------------------------------------------------------------------   




        setVisible(true);


    }


//--------------------------------------------------------------------- 

    public void actionPerformed(ActionEvent event){

        if (event.getSource() == buttonSignUpText) {
    
            SignUp signUp = new SignUp();
            
        } else if (event.getSource() == loginBtn) {

            if (userName.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Username fill cannot empty");
                    userName.requestFocus();
                    
            }else if (password.getText().isEmpty()) {
                    JOptionPane.showMessageDialog(null, "Password fill cannot empty");
            }else{
                loadData();
            }

            
        }



    }
//--------------------------------------------------------------------- 
    
public void loadData() {
    UserManagement userManagement = new UserManagement();
    User[] students = userManagement.getAll();

    if (students != null && students.length > 0) {
        String userNameInput = userName.getText();
        String passwordInput = new String(password.getPassword()); 

        boolean found = false;

        
        for (User user : students) {
            String userName = user.getuserName();
            String password = user.getPassword();

            
            if (userName.equals(userNameInput) && password.equals(passwordInput)) {
                
                found = true;
                Dashboard dashboard = new Dashboard();
                break; 
            }
        }

        
        if (!found) {
            JOptionPane.showMessageDialog(null, "Username or password incorrect");
        }
    } else {
        JOptionPane.showMessageDialog(null, "No users found");
    }
}


//--------------------------------------------------------------------- 
     




    
    
}