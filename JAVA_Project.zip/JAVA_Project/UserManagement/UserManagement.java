package UserManagement;

import GUIFiles.*;

import java.io.File;
import java.io.FileWriter;
import java.util.Scanner;

public class UserManagement {

    public void creatUser(User user){
        //write to file
        try{
            File f = new File("./Users.txt");
            FileWriter writer = new FileWriter(f,true);
            writer.write(user.getFileWriteFormat());
            writer.flush();
            writer.close();
        }catch(Exception e){

        }
    }

    public User[] getAll() {
        try {
            File file = new File("./Users.txt");
            Scanner scanner = new Scanner(file);
    
            int count = 0;
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!line.isEmpty()) {
                    count++;
                }
            }
            scanner.close();
            System.out.println("Total users: " + count);
    
            User[] users = new User[count];
            int index = 0;
    
            scanner = new Scanner(file);
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!line.isEmpty()) {
                    String[] info = line.split(";");
                    if (info.length == 5) { // Ensure correct line format
                        String userName = info[0];
                        String name = info[1];
                        String mobile = info[2];
                        String password = info[3];
                        String gender = info[4];
                        User user = new User(userName, name, mobile, password, gender);
                        users[index++] = user;
                    } else {
                        System.out.println("Invalid line format: " + line);
                    }
                }
            }
            scanner.close();
    
            return users;
        } catch (Exception e) {
            System.out.println("Error reading users: " + e.getMessage());
            return null;
        }
    }
    

    
}