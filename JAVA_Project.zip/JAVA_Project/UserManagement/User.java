package UserManagement;

import GUIFiles.*;

public class User {
    //registerData(usernameT,nameT, mobileT, passwordT, gender);
    private String username,name,mobile,password, gender;

    public User(String username,String name,String mobile,String password,String gender){
        this.username = username;
        this.name = name;
        this.mobile = mobile;
        this.password = password;
        this.gender = gender;

    }

    public String getuserName(){
        return this.username;
    }
    public String getName(){
        return this.name;
    }
    public String getMobile(){
        return this.mobile;
    }
    public String getPassword(){
        return this.password;
    }
    public String getGender(){
        return this.gender;
    }
    public String getFileWriteFormat(){
        return username+";"+name+";"+mobile+";"+password +";"+gender +"\n";
    }

    
}