package Product;

public class Product {

    private int id;
    private String name;
    private int quantity;
    private double price;

    public Product(int id, String name, int quantity, double price){
        this.id = id;
        this.name = name;
        this.quantity = quantity;
        this.price = price;
    }
    public void setQuantity(int quantity){
            this.quantity=quantity;
    }
    public int getProductId(){
        return this.id;
    }
    public String getProductName(){
        return this.name;
    }
    public void setProductName(String name){
        this.name=name;
}
    public void setProductQuantity(int quantity){
        this.quantity = quantity;
    }
    public int getProductQuantity(){
        return this.quantity;
    }
    public double getProductPrice(){
        return this.price;
    }
    public void setProductPrice(double price){
        this.price = price;
    }
    public String getFileWriteFormat(){
        return id+";"+name+";"+quantity+ ";"+ price + "\n";
    }
    public void show(){
        System.out.println("ID: " + id);
        System.out.println("Name: " + id);
        System.out.println("Quantity: " + quantity);
        System.out.println("Price: " + price);

    }
    
}
