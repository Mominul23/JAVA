package Product;

import java.io.File;
import java.io.FileWriter;
import java.util.ArrayList;
import java.util.Scanner;
import javax.swing.table.DefaultTableModel;

public class ProductManagment {

    private ArrayList<Product> products = new ArrayList<>();

    public ProductManagment() {
        loadProductsFromFile();
    }

    public void createProduct(Product p) {
        //write to file
        try {
            File f = new File("./Database/Products.txt");
            FileWriter writer = new FileWriter(f, true);
            writer.write(p.getFileWriteFormat());
            writer.flush();
            writer.close();
            products.add(p); // Update in-memory list
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public boolean delete(int id) {
        Product[] array = getAll();
        for (int i = 0; i < array.length; i++) {
            if (array[i].getProductId() == id) {
                array[i] = null;
                break;
            }
        }
        boolean result = writeToFile(array);
        return result;
    }

    public boolean update(Product p) { // p is updated value object
        Product[] array = getAll();  // array[i] existing object
        for (int i = 0; i < array.length; i++) {

            if (array[i].getProductId() == p.getProductId()) {
                array[i].setProductName(p.getProductName());
                array[i].setProductQuantity(p.getProductQuantity());
                array[i].setProductPrice(p.getProductPrice());
                break;
            }
        }
        boolean result = writeToFile(array);
        return result;
    }

    public boolean writeToFile(Product[] array) {
        try {
            File f = new File("./Database/Products.txt");
            FileWriter writer = new FileWriter(f);
            for (int i = 0; i < array.length; i++) {
                Product p = array[i];
                if (p != null)
                    writer.write(p.getFileWriteFormat());
            }
            writer.flush();
            writer.close();
            return true;
        } catch (Exception e) {
            e.printStackTrace();
            return false;
        }
    }

    public String sellProduct(int id, int quantity) {
        for (Product product : products) {
            if (product.getProductId() == id) {
                if (product.getProductQuantity() >= quantity) {
                    product.setProductQuantity(product.getProductQuantity() - quantity);
                    writeToFile(products.toArray(new Product[0])); // Persist changes
                    return "Sold " + quantity + " units of Product ID: " + id;
                } else {
                    return "Not enough stock for Product ID: " + id;
                }
            }
        }
        return "Product ID: " + id + " not found.";
    }

    public Product[] getAll() {
        return products.toArray(new Product[0]);
    }

    public void loadProductsFromFile() {
        try {
            File file = new File("./Database/Products.txt");
            Scanner scanner = new Scanner(file);
    
            while (scanner.hasNextLine()) {
                String line = scanner.nextLine();
                if (!line.isEmpty()) {
                    String[] info = line.split(";");
                    if (info.length == 4) { // Ensure correct line format
                        int productId = Integer.parseInt(info[0]);
                        String productName = info[1];
                        int productQuantity = Integer.parseInt(info[2]);
                        double productPrice = Double.parseDouble(info[3]);
                        Product product = new Product(productId, productName, productQuantity, productPrice);
                        products.add(product);
                    } else {
                        System.out.println("Invalid line format: " + line);
                    }
                }
            }
            scanner.close();
        } catch (Exception e) {
            System.out.println("Error reading Products: " + e.getMessage());
        }
    }

    public ArrayList<Product> getProducts() {
        return products;
    }

    public void loadData() {
        DefaultTableModel tableModel = new DefaultTableModel();
        tableModel.addColumn("Product ID");
        tableModel.addColumn("Product Name");
        tableModel.addColumn("Product Quantity");
        tableModel.addColumn("Product Price");

        ProductManagment productManagement = new ProductManagment();
        Product[] products = productManagement.getAll();

        if (products != null && products.length > 0) {
            for (Product product : products) {
                tableModel.addRow(new Object[]{
                    product.getProductId(),
                    product.getProductName(),
                    product.getProductQuantity(),
                    product.getProductPrice()
                });
            }
        } else {
            System.out.println("No products available to load.");
        }
    }
}
