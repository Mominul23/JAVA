package Product;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import GUIFiles.Dashboard;
import java.awt.*;
import java.awt.event.*;
import GUIFiles.*;

public class UpdateProduct extends JFrame implements ActionListener {


    Font font15 = new Font("Consolas",Font.PLAIN, 15);
    Font font18 = new Font("Consolas",Font.PLAIN, 18);
    Font timesRoman25 = new Font("TimesRoman",Font.BOLD, 25);
    Font timesRoman18 = new Font("TimesRoman",Font.PLAIN, 18);
    Font timesRoman30 = new Font("TimesRoman",Font.BOLD, 30);
    Font timesRoman25p = new Font("TimesRoman",Font.PLAIN, 25);
    Font font25 = new Font("Consolas",Font.BOLD, 25);

    private JButton backBtn,updateProduct;
    private JLabel label,nameProduct,idProduct,quantityProduct,priceProduct;
    private JTextField productFiele,idFiele,quantityFiele,productPrice;

    DefaultTableModel tableModel = new DefaultTableModel();



    public UpdateProduct(){

        super("Update Product");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLocation(150, 100);
        setLayout(null);

        backBtn = new JButton("Back");
        backBtn.setBounds(10, 10, 100, 30); //x,y,w,h
        backBtn.setFont(timesRoman18);
        backBtn.addActionListener(this);
        backBtn.setFocusable(false);
        add(backBtn);

        label = new JLabel("Update Product");
        label.setBounds(520,0,300,50);
        label.setFont(timesRoman30);
        add(label);


        
        idProduct = new JLabel("Product ID*");
        idProduct.setBounds(50,70,150,40);
        idProduct.setFont(timesRoman18);
        add(idProduct);

        idFiele = new JTextField();
        idFiele.setBounds(200, 70, 250, 40 );
        idFiele.setFont(timesRoman18);
        add(idFiele);

//------------------------------------------------------------------------------
        
        nameProduct = new JLabel("Product Name*");
        nameProduct.setBounds(50,120,150,40);
        nameProduct.setFont(timesRoman18);
        add(nameProduct);

        productFiele = new JTextField();
        productFiele.setBounds(200, 120, 250, 40 );
        productFiele.setFont(timesRoman18);
        add(productFiele);

//------------------------------------------------------------------------------

        quantityProduct = new JLabel("Product Quantity*");
        quantityProduct.setBounds(50,170,150,40);
        quantityProduct.setFont(timesRoman18);
        add(quantityProduct);

        quantityFiele = new JTextField();
        quantityFiele.setBounds(200, 170, 250, 40 );
        quantityFiele.setFont(timesRoman18);
        add(quantityFiele);

//------------------------------------------------------------------------------

        priceProduct = new JLabel("Product Price*");
        priceProduct.setBounds(50,220,150,40);
        priceProduct.setFont(timesRoman18);
        add(priceProduct);

        productPrice = new JTextField();
        productPrice.setBounds(200, 220, 250, 40 );
        productPrice.setFont(timesRoman18);
        add(productPrice);
//------------------------------------------------------------------------------

        updateProduct = new JButton("Update Product");
        updateProduct.setBounds(150, 280, 200, 40); //x,y,w,h
        updateProduct.setFont(timesRoman18);
        updateProduct.addActionListener(this);
        updateProduct.setFocusable(false);
        add(updateProduct);


        tableModel.addColumn("Product ID");
        tableModel.addColumn("Product Name");
        tableModel.addColumn("Product Quantity");
        tableModel.addColumn("Product Price");
         
        JTable table = new JTable(tableModel);
        JScrollPane jScrollPane = new JScrollPane(table);
        jScrollPane.setBounds(500, 70, 650,470);
        add(jScrollPane);


        
        table.addMouseListener(new MouseAdapter() {
            public void mouseClicked(MouseEvent e) {
                int selectedRow = table.getSelectedRow();
                if (selectedRow >= 0) {
                    idFiele.setText(tableModel.getValueAt(selectedRow, 0).toString());
                    productFiele.setText(tableModel.getValueAt(selectedRow, 1).toString());
                    quantityFiele.setText(tableModel.getValueAt(selectedRow, 2).toString());
                    productPrice.setText(tableModel.getValueAt(selectedRow, 3).toString());
                }
            }
        });











        setVisible(true);

        loadData();




        
    }

    
    public void actionPerformed(ActionEvent event) {

        if (event.getSource() == backBtn) {

            Dashboard dashboard = new Dashboard();
            
        }else if (event.getSource() == updateProduct ) {

            try {

                try {

                    int id = Integer.parseInt(idFiele.getText());
                    String name = productFiele.getText();
                    int quantity = Integer.parseInt(quantityFiele.getText());
                    double price = Double.parseDouble(productPrice.getText());
    
                    ProductManagment productManagment = new ProductManagment();
                    Product product = new Product(id, name, quantity, price);
                    productManagment.update(product);
                    loadData();
                    
                } catch (Exception e) {
                    // TODO: handle exception
                }

               
        
                
            } catch (Exception e) {
                // TODO: handle exception
            }

           
            
        }



        
    }


    public void loadData() {

        
        ProductManagment productManagement = new ProductManagment();
        Product[] products = productManagement.getAll();

        if (products != null && products.length > 0) {
            for (int i = 0; i < products.length; i++) {
                Product product = products[i]; // Corrected array access syntax
                tableModel.addRow(new Object[]{
                    product.getProductId(),
                    product.getProductName(),
                    product.getProductQuantity(),
                    product.getProductPrice()
                });
            }
        } else {
            System.out.println("No products available to load.");
        }
    }

    
}
