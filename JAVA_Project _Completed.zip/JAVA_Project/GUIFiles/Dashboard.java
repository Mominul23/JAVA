package GUIFiles;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

import Product.*;
import UserManagement.*;


public class Dashboard  extends JFrame implements ActionListener{

    Font font15 = new Font("Consolas",Font.PLAIN, 15);
    Font font18 = new Font("Consolas",Font.PLAIN, 18);
    Font timesRoman25 = new Font("TimesRoman",Font.BOLD, 25);
    Font timesRoman18 = new Font("TimesRoman",Font.PLAIN, 18);
    Font timesRoman30 = new Font("TimesRoman",Font.BOLD, 30);
    Font timesRoman25p = new Font("TimesRoman",Font.PLAIN, 25);
    Font font25 = new Font("Consolas",Font.BOLD, 25);
    Font fontmr = new Font("serif", Font.BOLD, 35);
    Font timesRoman15 = new Font("TimesRoman",Font.PLAIN, 15);

    JTextField name, id, address;
    JButton add, logout, signup, addProduct, sellProduct ,updateProduct, deleteProduct, showAllProduct;
    JLabel output,text,label, label2,userTopTitle, userLable,
     nameLable, mobilelable, genderLable, textProduct, selfFeeds;
    

    public Dashboard(){

        
        super("Dashboard");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(1200, 600);
        setLocation(150, 100);
        setLayout(null);

        label = new JLabel("User Dashboard");
        label.setBounds(520,10,300,50);
        label.setFont(timesRoman30);
        add(label);

        label2 = new JLabel("Welcome to our Products Managment System");
        label2.setBounds(370,60,750,50);
        label2.setFont(timesRoman25p);
        add(label2);
        

        userTopTitle = new JLabel("User Details");
        userTopTitle.setBounds(25,55, 150, 40);
        userTopTitle.setFont(timesRoman25);
        add(userTopTitle);

        userLable = new JLabel("User Name");
        userLable.setBounds(25,100, 250, 40);
        userLable.setFont(timesRoman18);
        add(userLable);

        nameLable = new JLabel("Name");
        nameLable.setBounds(25,140, 250, 40);
        nameLable.setFont(timesRoman18);
        add(nameLable);


        mobilelable = new JLabel("Mobile");
        mobilelable.setBounds(25,180, 250, 40);
        mobilelable.setFont(timesRoman18);
        add(mobilelable);

        genderLable = new JLabel("Gender");
        genderLable.setBounds(25,220, 250, 40);
        genderLable.setFont(timesRoman18);
        add(genderLable);

        textProduct = new JLabel("Product Managment System");
        textProduct.setBounds(550,130, 450, 50);
        textProduct.setFont(fontmr);
        add(textProduct);


        sellProduct = new JButton("Sell Product");
        sellProduct.setBounds(460, 200, 250, 50); //x,y,w,h
        sellProduct.setFont(timesRoman18);
        sellProduct.addActionListener(this);
        sellProduct.setFocusable(false);
        add(sellProduct);


        addProduct = new JButton("Add Product");
        addProduct.setBounds(760, 200, 250, 50); //x,y,w,h
        addProduct.setFont(timesRoman18);
        addProduct.addActionListener(this);
        addProduct.setFocusable(false);
        add(addProduct);

        updateProduct = new JButton("Update Product");
        updateProduct.setBounds(460, 300, 250, 50); //x,y,w,h
        updateProduct.setFont(timesRoman18);
        updateProduct.addActionListener(this);
        updateProduct.setFocusable(false);
        add(updateProduct);

        deleteProduct = new JButton("Delete Product");
        deleteProduct.setBounds(760, 300, 250, 50); //x,y,w,h
        deleteProduct.setFont(timesRoman18);
        deleteProduct.addActionListener(this);
        deleteProduct.setFocusable(false);
        add(deleteProduct);


        showAllProduct = new JButton("Show All Products");
        showAllProduct.setBounds(580, 400, 300, 50); //x,y,w,h
        showAllProduct.setFont(timesRoman18);
        showAllProduct.addActionListener(this);
        showAllProduct.setFocusable(false);
        add(showAllProduct);


        

//---------------------------------------------------------------------       

        selfFeeds = new JLabel("JAVA [Section : CCC]/2024");
        selfFeeds.setBounds(950,510, 350, 40);
        selfFeeds.setFont(timesRoman15);
        add(selfFeeds);

    
        
   //---------------------------------------------------------------------  
   
   
        logout = new JButton("Logout");
        logout.setBounds(40, 500, 150, 30); //x,y,w,h
        logout.setFont(timesRoman18);
        logout.addActionListener(this);
        logout.setFocusable(false);
        add(logout);
      
        //---------------------------------------------------------------------   



        setVisible(true);

        loadData();

    }  //--------------------------------------------------------------------- 

    public void actionPerformed(ActionEvent event){

        if(event.getSource() == add){

           // tableModel.addRow(new Object[]{name.getText(),id.getText(),address.getText()});
        

        }else if (event.getSource() == logout) {

            int choice = JOptionPane.showConfirmDialog(null, "Are you sure you want to logout?", "Logout", JOptionPane.YES_NO_OPTION);
            if (choice == JOptionPane.YES_OPTION) {
                dispose(); 
                Login login = new Login(); 
            }
            
        }else if (event.getSource() == addProduct) {

                AddProduct addProduct = new AddProduct();
                 
        }else if (event.getSource() == sellProduct) {
            
                SellProduct sellProduct = new SellProduct(); 
     
        }
        else if (event.getSource() == deleteProduct) {
        
                DeleteProduct deleteProduct = new DeleteProduct();
       
        }else if (event.getSource() == updateProduct) {
            
               UpdateProduct updateProduct =new UpdateProduct();
            
        }else if (event.getSource() == showAllProduct) {

            ShowAllProduct aShowAllProduct = new ShowAllProduct();
            
        }



    }
//--------------------------------------------------------------------- 

//--------------------------------------------------------------------- 
    
public void loadData() {
    UserManagement userManagement = new UserManagement();
    User[] students = userManagement.getAll();

    if (students != null && students.length > 0) {
        
        

        
        for (User user : students) {
            String userName = user.getuserName();  
            String password = user.getPassword();  
            String name = user.getName();  
            String mobile = user.getMobile();
            String gender = user.getGender();

            label2.setText("Hey "+ name + ", " +"Welcome to our Dashboard" );  
            nameLable.setText("Name          : "+name);
            userLable.setText("User Name : "+ userName);
            mobilelable.setText("Mobile         : "+ mobile);
            genderLable.setText( "Gender       : "+ gender);
            //text.setText(name);    
            
        }
    } else {
        JOptionPane.showMessageDialog(null, "No users found");
    }
}

//--------------------------------------------------------------------- 
     
    



    
}