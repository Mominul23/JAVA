
public class Car{
	public String carName;
	public String color;
	public String model;
	public String ownerName;
	public double yesrsofUse;
	
	public Car(){
		
	}
	public Car(String cName, String col, String mdl, String ow, double you){
		carName = cName;
		color = col;
		model = mdl;
		ownerName = ow;
		yesrsofUse = you;
		
	}
	///////
	public void setcName(String cn){
		this.carName = cn;
	}
	public String getcName(){
		return carName;
	}
	//////////
	public void setowner(String co){
		this.ownerName = co;
	}
	public String getcarName(){
		return ownerName;
	}
	//////////
	public void setcColor(String cl){
		this.color = cl;
	}
	public String getColor(){
		return color;
	}
	//////////
	public void setModel(String cm){
		this.model = cm;
	}
	public String getModel(){
		return model;
	}
	//////////
	public void setUse(double cu){
		this.yesrsofUse = cu;
	}
	public double getCuse(){
		return yesrsofUse;
	}
	//////////
	
	public void CarShowInfo(){
		System.out.println("\n           Welcome " + ownerName + ", as a Car Owner" );
        System.out.println("     Car Name         : " + carName);
        System.out.println("     Car Color        : " + color);
        System.out.println("     Car Model        : " + model);
        System.out.println("     Car yesrs of Use : " + yesrsofUse + " Years");
        System.out.println("     Car Owner Name   : " + ownerName);
        
	}
	
		
}