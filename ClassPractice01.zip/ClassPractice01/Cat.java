
public class Cat {

    private String name;
    private String color;
    private double height;
    private double weight;
    
    public Cat(){

    }

    public Cat(String Name, String Colour, double Hiet, double Wet){
        name= Name;
        color = Colour;
        height = Hiet;
        weight = Wet;
    }
    //////////////
    public void setName(String Nmmmm){
        this.name = Nmmmm;
    }
    public String getName(){
        return name;
    }
    /////////
    public void setCol(String collll){
        this.color = collll;
    }
    public String getCol(){
        return color;
    }
    ////////

    public void setHeight(double ht){
        this.height = ht;
    }
    public double getHeight(){
        return height;
    }
    //////////
    public void setWeight(double wt){
        this.weight = wt;
    }
    public double getWeight(){
        return weight;
    }

    //////////
    public void Cat_ShowInfo(){

        System.out.println("\n           Welcome " + name + ", as a Grimalkin " );
        System.out.println("     Cat Name      : " + name);
        System.out.println("     Height        : " + height + " inches");
        System.out.println("     Weight        : " + weight + " KG");
        System.out.println("     My Cat Color  : " + color);
        
    }
    ////////////////
}