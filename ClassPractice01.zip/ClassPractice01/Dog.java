public class Dog {

    private String name;
    private String color;
    private double height;
    private double weight;
    
    public Dog(){

    }
    public Dog(String Name, String Colour, double Hiet, double wet){
        name= Name;
        color = Colour;
        height = Hiet;
        weight = wet; 

    }

     //////////////
     public void setName(String Nmmmm){
        this.name = Nmmmm;
    }
    public String getName(){
        return name;
    }
    /////////
    public void setCol(String collll){
        this.color = collll;
    }
    public String getCol(){
        return color;
    }
    ////////

    public void setHeight(double ht){
        this.height = ht;
    }
    public double getHeight(){
        return height;
    }
    //////////
    public void setWeight(double wt){
        this.weight = wt;
    }
    public double getWeight(){
        return weight;
    }

    //////////
    public void Dog_ShowInfo(){

        System.out.println("\n           Welcome " + name + ", as a Barker " );
        System.out.println("     Cat Name      : " + name);
        System.out.println("     Height        : " + height + " inches");
        System.out.println("     Weight        : " + weight + " KG");
        System.out.println("     My Dog Color  : " + color);
        
    }
    ////////////////
}