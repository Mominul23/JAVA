
public class Main {

    public static void main(String [] args){


        Human h1 = new Human("Md Mominul Islam", 5.8 , 70 , "purple", 22 , "01-03-2003");
        h1.Human_ShowInfo();

        Cat c1 = new Cat("Mangu", "white and red", 20, 3);
        c1.Cat_ShowInfo();

        Dog d1 = new Dog("HONN", "Black and white", 40, 8);
        d1.Dog_ShowInfo();
		
		Building b1 = new Building("NAZRUL VILLA" , "Shibganj" , 3400 , "MD Nazrul Islam" , "Md Mominul islam", "5845847652", "4545jjybhd");
		b1.BuildingShowInfo();

        Duck d11 = new Duck("Duck", "white", 25, 4);
        d11.Duck_ShowInfo();
		
		Car car1 = new Car("BMW", "RED", "1815", "Md Mominul Islam" , 5);
		car1.CarShowInfo();
		





    }
}