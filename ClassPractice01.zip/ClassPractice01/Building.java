
public class Building{
	public String builName;
	public String address;
	public double size;
	public String ownerName;
	public String engName;
	public String permitNo;
	public String licenseNo;
	
	public Building(){
		
	}
	
	public Building(String bname, String add, double siz, String OwName, String engNam, String pN, String LN){
		builName = bname;
		address = add;
		size = siz;
		ownerName = OwName;
		engName = engNam;
		permitNo = pN;
		licenseNo = LN;
		
	}
	//////////////
	public void setbName(String bn){
		this.builName = bn;
	}
	public String getbName(){
		return builName;
	} 
	/////////////
	public void setAdd(String ad){
		this.address = ad;
	}
	public String getAddress(){
		return address;
	}
	/////////
	public void setSize(double sz){
		this.size = sz;
	}
	public double getsz(){
		return size;
	}
	///////////
	public void setOW(String ow){
		this.ownerName = ow;
	}
	public String getOW(){
		return ownerName;
	}
	///////////
	public void setEName(String en){
		this.engName = en;
	}
	public String getEname(){
		return engName;
	}
	//////////
	public void setPermitNo(String pm){
		this.permitNo = pm;
	}
	String getPN(){
		return permitNo;
	}
	//////////
	public void setLNo(String LNO){
		this.licenseNo = LNO;
	}
	String getLiNo(){
		return licenseNo;
	}
	
	public void BuildingShowInfo(){
		 System.out.println("\n           Welcome " + engName + ", as a Engineer " );
        System.out.println("     Building Name        : " + builName);
        System.out.println("     Address      		  : " + address );
        System.out.println("     Size        		  : " + size + " Sq Feet");
        System.out.println("     Building owner Name  : " + ownerName);
        System.out.println("     Engineer Name  	  : " + engName);
        System.out.println("     Permit No  		  : " + permitNo);
        System.out.println("     License No 		  : " + licenseNo);
        
        
	}
	
	
	
}