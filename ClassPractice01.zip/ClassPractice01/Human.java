
public class Human {

    public String name;
    public double height;
    public double weight;
    public String color;
    public double age;
    public String dob;


public Human(){

}

public Human(String Name, double Hight, double Wet, String col, double Age, String Dobb){
    name = Name;
    height = Hight;
    weight = Wet;
    color = col;
    age =Age;
    dob = Dobb;

}

///////
public void NameSet(String NaMe){
    this.name= NaMe;
}
public String NameGet(){
    return name;
}
////////
public void setHight(double Htt){
    this.height = Htt;
}
public double hightGet(){
    return height;
}
///////
public void weightSet(double Wttt){
    this.weight = Wttt;
}
public double weightGet(){
    return weight;
}
////////
public void SetCol( String colll){
    this.color = colll;
}
public String GetCol(){
    return color;
}
//////////
public void Setage(double agggg){
    this.age = agggg;
}
public double Getage(){
    return age;
}
///////////////

public void SetDob(String dobbbbb){
    this.dob = dobbbbb;
}
public String Getdob(){
    return dob;
}

///////
public void Human_ShowInfo(){

    System.out.println("           Welcome " + name + ", as a Human " );
    System.out.println("     Name         	    : " + name);
    System.out.println("     Age          	    : " + age + " Years old");
    System.out.println("     Height       	    : " + height + " Feet");
    System.out.println("     Weight       	    : " + weight + " KG");
    System.out.println("	 Date of birth      : " + dob);
    System.out.println("	 My favourite Color : " + color);
    
}


///////////

}