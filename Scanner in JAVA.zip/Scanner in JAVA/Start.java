import java.util.Scanner;

public class Start{

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);


        System.out.println("\n  WELCOM TO OUR SCANNER FUNCTION IN JAVA   ");
        
        System.out.print("\nEnter your name  : ");
        String name = s.nextLine();

        System.out.print("Enter your AIUB ID : ");
        String uid = s.nextLine();

        System.out.print("Enter your Address : ");
        String add = s.nextLine();

        System.out.print("Enter your age     : ");
        int age = s.nextInt();

        System.out.print("Enter your salary  : ");
        float salary = s.nextFloat();

        System.out.print("Enter your Mobile  : ");
        int mobile = s.nextInt();

        System.out.print("Enter your salary2  : ");
        float salaryy = s.nextFloat();

        System.out.print("Enter your Marital Status  : ");
        boolean Marital = s.nextBoolean();

        

       


        System.out.println("\nYour Name        : "+ name);
        System.out.println("Your age           : "+ age);
        System.out.println("Your Address       : "+ add);
        System.out.println("Your Salary        : " + salary +" Taka only");
        System.out.println("Your Salary2        : " + salaryy +" Taka only");
        System.out.println("Your Mobile Number : "+ mobile);
        System.out.println("Your AIUB ID       : "+ uid);
        System.out.println("Your AIUB ID       : "+ Marital);



        
        

    }
}